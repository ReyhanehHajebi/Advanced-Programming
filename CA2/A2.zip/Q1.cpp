#include <iostream>
#include <string>
#include <vector>

using namespace std;

double core_i3 (int generation)
{
    if(generation == 1)
      return 1;

 return 1.5 * core_i3(generation-1);

}


double core_i5(int generation)
{
    if(generation == 1)
       return 1.4;

   return (1.2 * core_i5( generation-1)) + (0.2 * core_i3(generation));


}


double core_i7(int generation)
{
  if(generation == 1)
     return 1.7;



return (1.3 * core_i7(generation - 1 )) + (0.3 * core_i5 (generation)) + (0.2 * core_i3(generation));

}

int find_generation(int year)
{
  if (year == -1 or year == 0 or year == 1)
     return 0;


  return  1 + find_generation( year - 2) ; 
}


void find_cpupow()
{

  int year;
  cin >> year;
  int remain = year % 3;
  int generation = find_generation(year);
  if(remain == 1)
  {
      double output;

      output = core_i3(generation);

      cout << "core i3" << endl << output << endl;

  }

  if(remain == 2)
  { 
    double output;

    output = core_i5(generation);

    cout << "core i5" << endl << output << endl;

  }

  if(remain == 0)
  { 
    double output;

    output = core_i7(generation);

    cout << "core i7" << endl << output << endl;

  }




  
}

int main ()
{

  find_cpupow();
  

}