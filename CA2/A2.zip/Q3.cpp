#include <iostream>

using namespace std;

#define empty 0
#define N 9


bool missinglocation(int sudoku[N][N],int& row, int& col)
{
	for (row = 0; row < N; row++)
		for (col = 0; col < N; col++)
			if (sudoku[row][col] == empty)
				return true;
	return false;
}

bool Checkrow(int sudoku[N][N], int row, int number)
{
	for (int col = 0; col < N; col++)
		if (sudoku[row][col] == number)
			return true;
	return false;
}

bool Checkcol(int sudoku[N][N], int col, int number)
{
	for (int row = 0; row < N; row++)
		if (sudoku[row][col] == number)
			return true;
	return false;
}

bool Checkbox(int sudoku[N][N], int boxStartRow,int boxStartCol, int number)
{
	for (int row = 0; row < 3; row++)
		for (int col = 0; col < 3; col++)
			if (sudoku[row + boxStartRow][col + boxStartCol] == number)
				return true;
	return false;
}

bool check(int sudoku[N][N], int row,int col, int number)
{
	return !Checkrow(sudoku, row, number)&& !Checkcol(sudoku, col, number)
	       && !Checkbox(sudoku, row - row % 3,col - col % 3, number)
	    	&& sudoku[row][col] == empty;
}

void print_s(int sudoku[N][N])
{
    
    cout << endl;
	for (int row = 0; row < N; row++)
	{
		for (int col = 0; col < N; col++)
			cout << sudoku[row][col] << " ";
		cout << endl;
	}
}

bool Solver(int sudoku[N][N])
{
	int row, col;
	if (!missinglocation(sudoku, row, col))
	 return true;

	for (int number = 1; number <= 9; number++)
	{
		if (check(sudoku, row, col, number))
		{
			sudoku[row][col] = number;
			if (Solver(sudoku))
				return true;
			sudoku[row][col] = empty;
		}
	}
	return false;
}

void get_input(int sudoku[N][N])
{

  for(int i = 0;i < N;i++)
	 for(int j = 0;j < N;j++)
	cin >> sudoku[i][j];

}

int main()
{
    
	int sudoku[N][N];

	get_input(sudoku);

	if (Solver(sudoku) == true)
	print_s(sudoku);
	
return 0;
}
