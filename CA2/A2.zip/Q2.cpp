#include <iostream>
#include <string>

using namespace std;

void reverseit(string &words, int first, int last) {

   int length = words.length();
   

    if (length == 0 || last > length || first >= last) {
        return;
    }

    char temp = words[last];
    words[last] = words[first];
    words[first] = temp;

    reverseit(words, first + 2, last - 1);
}

int main()
{

    string str;
    cin >> str;

   //string str = "abcdefghijklmnopqrstuvwxyz";

   int first = 0 ;
   int last = str.length()-1;

    reverseit(str, first, last);

    cout << str << endl;

}